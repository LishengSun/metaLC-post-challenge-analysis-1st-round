import random
import numpy as np
from collections import defaultdict
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import StandardScaler

class Agent():
    """
    RANDOM SEARCH AGENT
    """

    def __init__(self, number_of_algorithms):
        """
        Initialize the agent

        Parameters
        ----------
        number_of_algorithms : int
            The number of algorithms

        """
        self.nA = number_of_algorithms

    def reset(self, dataset_meta_features, algorithms_meta_features):
        """
        Reset the agents' memory for a new dataset

        Parameters
        ----------
        dataset_meta_features : dict of {str : str}
            The meta-features of the dataset at hand, including:
                'usage' : name of the competition
                'name' : name of the dataset
                'task' : type of the task
                'target_type' : target type
                'feat_type' : feature type
                'metric' : evaluation metric used
                'time_budget' : time budget for training and testing
                'feat_num' : number of features
                'target_num' : number of targets
                'label_num' : number of labels
                'train_num' : number of training examples
                'valid_num' : number of validation examples
                'test_num' : number of test examples
                'has_categorical' : presence or absence of categorical variables
                'has_missing' : presence or absence of missing values
                'is_sparse' : full matrices or sparse matrices

        algorithms_meta_features : dict of dict of {str : str}
            The meta_features of all algorithms
        """
        self.dataset_meta_features = dataset_meta_features
        self.algorithms_meta_features = algorithms_meta_features
        self.validation_last_scores = []
        self.validation_last_timestep = []

        self.ck = 0
        self.last_dt = 0
        self.best_val_score = 0
        self.best_alg = None

    def meta_train(self, datasets_meta_features, algorithms_meta_features, validation_learning_curves,
                   test_learning_curves):
        """
        Start meta-training the agent with the validation and test learning curves

        Parameters
        ----------
        datasets_meta_features : dict of dict of {str: str}
            Meta-features of meta-training datasets

        algorithms_meta_features : dict of dict of {str: str}
            The meta_features of all algorithms

        validation_learning_curves : dict of dict of {int : Learning_Curve}
            VALIDATION learning curves of meta-training datasets

        test_learning_curves : dict of dict of {int : Learning_Curve}
            TEST learning curves of meta-training datasets
        """


        self.validation_learning_curves = validation_learning_curves
        self.test_learning_curves = test_learning_curves
        self.datasets_meta_features = datasets_meta_features
        self.algorithms_meta_features = algorithms_meta_features

        """
        Train a P(erformance) and a T(ime budget) SVR for each timestep
        """

        # 1. Determine how many SVRs we need, and how many datapoints we have for each SVR
        self.train_datasets_ids = [k for k in test_learning_curves]
        self.algo_ids = [k for k in test_learning_curves[self.train_datasets_ids[0]].keys()]

        max_steps = 0
        steps_dist = defaultdict(lambda: 0)
        steps_per_curve = defaultdict(lambda: [])  # {num_points: [(ds, algo),...(ds, algo)]}

        for d in self.train_datasets_ids:
            for a in self.algo_ids:
                l = len(self.validation_learning_curves[d][a].scores)
                steps_dist[l] += 1

                for i in range(0, l):
                    steps_per_curve[i].append((d, a))

                if l > max_steps:
                    max_steps = l

        print(f"Curve points distribution {dict(steps_dist)}")
        print(f"Max datapoints per curve: {max_steps}")

        """
        2.
        SVRp_i = [(algo_f1, algo_f2), (dsf_1, ...., dsf_n), (valP_0, ..., valP(i-1))] -> testP(i)
        SVRt_i = [(algo_f1, algo_f2), (dsf_1, ...., dsf_n), (valT_0, ..., valT(i-1))] -> testT(i)
        """

        self.SVR_p = {}
        self.SVR_t = {}

        for l, dp in steps_per_curve.items():
            # Retrieve: SVR training data
            ds_ids = [i[0] for i in dp]
            algo_ids = [i[1] for i in dp]

            ds_features = {i: self._ds_to_vec(self.datasets_meta_features[i]) for i in ds_ids}
            alg_features = {i: self._algo_to_vec(self.algorithms_meta_features[i]) for i in algo_ids}

            P_dataset, P_labels = [], []
            T_dataset, T_labels = [], []

            for ds, alg in dp:
                ds_vector = ds_features[ds]
                alg_vector = alg_features[alg]

                val_P = self.validation_learning_curves[ds][alg].scores[:l]
                val_T = self.validation_learning_curves[ds][alg].timestamps[:l]
                test_P = self.test_learning_curves[ds][alg].scores[l]
                test_T = self.test_learning_curves[ds][alg].timestamps[l]

                P_datapoint = np.concatenate([alg_vector, ds_vector, val_P])
                T_datapoint = np.concatenate([alg_vector, ds_vector, val_T])

                P_dataset.append(P_datapoint)
                T_dataset.append(T_datapoint)
                P_labels.append(test_P)
                T_labels.append(test_T)

            P_dataset = np.stack(P_dataset, axis=0).astype(np.float32)
            Pscaler = StandardScaler()
            P_dataset = Pscaler.fit_transform(P_dataset)

            T_dataset = np.stack(T_dataset, axis=0).astype(np.float32)
            Tscaler = StandardScaler()
            T_dataset = Tscaler.fit_transform(T_dataset)

            P_labels = np.stack(P_labels, axis=0).astype(np.float32)
            T_labels = np.stack(T_labels, axis=0).astype(np.float32)

            # Train the two SVR
            tuned_parameters = {"C": [0.1, 1, 100, 1000],
                                 "epsilon": [0.001, 0.005, 0.01, 0.05, 0.1, 0.5]}

            """
            svr_P = GridSearchCV(SVR(kernel="rbf", gamma="auto"), tuned_parameters, cv=3, scoring='max_error', verbose=1, n_jobs=8)
            svr_T = GridSearchCV(SVR(kernel="rbf", gamma="auto"), tuned_parameters, cv=3, scoring='max_error', verbose=1, n_jobs=8)"""

            #svr_P = SVR(kernel="rbf", C=100, gamma=0.1, epsilon=0.1)
            #svr_T = SVR(kernel="rbf", C=100, gamma=0.1, epsilon=0.1)
            svr_P = RandomForestRegressor(20)
            svr_T = RandomForestRegressor(20)
            svr_P.fit(P_dataset, P_labels)
            svr_T.fit(T_dataset, T_labels)

            self.SVR_p[l] = (svr_P, Pscaler)
            self.SVR_t[l] = (svr_T, Tscaler)


    def _ds_to_vec(self, ds):

        conver = {
            "usage": None,
            "name": None,
            "task": {
                "binary.classification": 0,
                "multiclass.classification": 1,
                "multilabel.classification": 2,
                "regression": 3
            },
            "target_type": {
                "Binary": 0,
                "Categorical": 1,
                "Numerical": 2,
            },
            "feat_type": {
                "Binary": 0,
                "Categorical": 1,
                "Numerical": 2,
                "Mixed": 3
            },
            "metric": {
                "bac_metric": 0,
                "auc_metric": 1,
                "f1_metric": 2,
                "pac_metric": 3,
                "abs_metric": 4,
                "r2_metric": 5,
                "a_metric": 6,
            },
        }

        dv = []
        for k, v in ds.items():
            cd = conver.get(k, {})
            if cd is None:
                continue

            item = cd.get(v, None)
            if item is None:
                item = ds[k]
            dv.append(item)

        return np.array(dv, dtype=np.float32)

    def _algo_to_vec(self, algo):
        av = [algo['meta_feature_0'], algo['meta_feature_1']]
        return np.array(av, dtype=np.float32)

    def suggest(self, observation):
        """
        Return a new suggestion based on the observation

        Parameters
        ----------
        observation : tuple of (int, float, float)
            The last observation returned by the environment containing:
                (1) A: the explored algorithm,
                (2) C_A: time has been spent for A
                (3) R_validation_C_A: the validation score of A given C_A

        Returns
        ----------
        action : tuple of (int, int, float)
            The suggested action consisting of 3 things:
                (1) A_star: algorithm for revealing the next point on its TEST learning curve
                            (which will be used to compute the agent's learning curve)
                (2) A:  next algorithm for exploring and revealing the next point
                       on its VALIDATION learning curve
                (3) delta_t: time budget will be allocated for exploring the chosen algorithm in (2)

        Examples
        ----------
        >>> action = agent.suggest((9, 151.73, 0.5))
        >>> action
        (9, 9, 80)
        """

        if observation is not None and observation[1] != 0:
            self.validation_last_timestep.append(observation[1])
            self.validation_last_scores.append(observation[2])
            self.last_dt = 0

            if observation[2] > self.best_val_score:
                self.best_alg = observation[0]

        elif observation is not None and observation[1] == 0:
            self.last_dt += 10
            action = (observation[0], observation[0], self.last_dt)
            return action

        P_pred = []
        T_pred = []

        # Predict P and T for all algorithms and the current dataset
        for alg_idx, alg in self.algorithms_meta_features.items():
            alg_vector = self._algo_to_vec(alg)
            ds_vector = self._ds_to_vec(self.dataset_meta_features)
            val_P = self.validation_last_scores[:self.ck]
            val_T = self.validation_last_timestep[:self.ck]

            SVRp, Pscaler = self.SVR_p[self.ck]
            SVRt, Tscaler = self.SVR_t[self.ck]

            P_datapoint = np.concatenate([alg_vector, ds_vector, val_P])
            P_datapoint = Pscaler.transform(P_datapoint[np.newaxis, :])

            T_datapoint = np.concatenate([alg_vector, ds_vector, val_T])
            T_datapoint = Tscaler.transform(T_datapoint[np.newaxis, :])

            pred_P = SVRp.predict(P_datapoint)
            P_pred.append(pred_P)
            pred_T = SVRt.predict(T_datapoint)
            T_pred.append(pred_T)

        # Select best performing algorithm
        best_ind = np.array(P_pred).argmax()
        delta_t = T_pred[best_ind]
        self.last_dt = delta_t

        if self.best_alg is None:
            self.best_alg = best_ind

        self.ck += 1
        action = (self.best_alg, best_ind, delta_t[0].item())
        return action
